<?php

session_start();

include '../php/config.php';

if ($con) {
    echo " connection successful";
} else {
    echo " no connection";
}

mysqli_select_db($con, 'adminpro');


$username = $_POST['username'];
$password = $_POST['password'];

$q = " select * from adminpro where username = '$username' && password = '$password' ";

$result = mysqli_query($con, $q);

$num = mysqli_num_rows($result);

if ($num == 1) {
    $_SESSION['proadminname'] = $username;
    header('location:./dashboard.php');
} else {
    header('location:./index.html');
}
