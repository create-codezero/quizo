<?php

session_start();

if (!isset($_SESSION['adminname'])) {
    header('location:index.html');
}

include '../php/config.php';

$quizname = $_GET['quizname'];

mysqli_select_db($con, 'addquiz');

if (isset($_POST['submit'])) {

    $answera = $_POST['answera'];
    $answerb = $_POST['answerb'];
    $answerc = $_POST['answerc'];
    $answerd = $_POST['answerd'];
    $ansid = $_POST['ansid'];
    $question = $_POST['question'];
    $ans = $_POST['ans'];

    $q_1 = " INSERT INTO `answers_$quizname`(`ans`, `q_id`) VALUES ('$answera','$ansid'),('$answerb','$ansid'),('$answerc','$ansid'),('$answerd','$ansid') ";
    mysqli_query($con, $q_1);
    $q = " INSERT INTO `questions_$quizname`(`question`, `ans`) VALUES ('$question','$ans') ";
    $qqq = mysqli_query($con, $q);

    header('location: quizs.php?quizname=' . $quizname);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <title>Make A quiz | admin | quizo</title>
    <script>
        function fn1() {
            alert("Don't Enter Question Number before question....");
        }
    </script>
</head>

<body>

    <div class="container-fluid m-auto bg-danger">

        <form class="form-group m-auto border-success w-75" method="post"><br>

            <h2 class="bg-dark text-light py-2 font-weight-bold">Enter Question And Answer Here</h2><br>
            <h2>Question</h2>
            <input class="form-control" name="question" onclick="fn1()" placeholder="Enter question without question number"><br><br>
            <input class="form-control" type="number" name="ans" placeholder="Enter Answer Id"><br><br>

            <br><br><br><br>

            <h2>Answer</h2>

            <input class="form-control" name="answera" value="A . "><br><br>
            <input class="form-control" name="answerb" value="B . "><br><br>
            <input class="form-control" name="answerc" value="C . "><br><br>
            <input class="form-control" name="answerd" value="D . "><br><br>

            <input class="form-control" type="number" name="ansid" placeholder="Enter Question Id"><br><br>

            <input class="btn btn-success m-auto" type="submit" value="Submit" name="submit">

        </form>

    </div>

</body>

</html>