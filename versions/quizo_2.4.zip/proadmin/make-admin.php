<?php

session_start();

if (!isset($_SESSION['proadminname'])) {
    header('location:./index.html');
}

include '../php/config.php';

if ($con) {
} else {
    echo " no connection";
}

mysqli_select_db($con, 'admin');


$username = $_POST['username'];
$password = $_POST['password'];

$qyy = " INSERT INTO `admin`(`username`, `password`) VALUES ('$username','$password') ";
mysqli_query($con, $qyy);
$qy = " INSERT INTO `list_admin`(`teacher`) VALUES ('$username') ";
mysqli_query($con, $qy);

$qc = " CREATE TABLE `addquiz_$username` (
    `id` int(255) auto_increment  NOT NULL primary key,
    `quizname` varchar(255) NOT NULL,
    `time` varchar(255) NOT NULL,
    `condby` varchar(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1; ";

mysqli_query($con, $qc);

?>
<script>
    alert("added sucessfully!");
</script>

<?php

header('location: ./dashboard.php');

?>