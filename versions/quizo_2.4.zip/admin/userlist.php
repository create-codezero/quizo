<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../style/userlist.css">
    <title>Userlist</title>
</head>

<body>
    <div class="user-div">
        <div class="main-table">
            <table id="customers">
                <?php

                include '../php/config.php';

                $sql = "SELECT * FROM registereduser";

                $result = mysqli_query($con, $sql);

                if (mysqli_num_rows($result) > 0) {
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>Id</th><th>Fast name</th><th>Last name</th><th>School name</th><th>class</th><th>mobile</th><th>gmail</th><th>quizo Id</th><th>Password</th><th>Update</th><th>Delete</th><th>Img Path</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    while ($row = mysqli_fetch_assoc($result)) {

                        echo "<tr>";
                        echo "<td>";
                        echo $row['Id'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['fname'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['lname'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['sname'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['class'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['mobile'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['gmail'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['quizoid'];
                        echo "</td>";
                        echo "<td>";
                        echo $row['password'];
                        echo "</td>";
						echo "<td>";
                        echo $row['path'];
                        echo "</td>";

                        ?>

                        <td><button class="del-btn"><a href="../php/delete.php?id=<?php echo $row['Id']; ?>">Delete</a></button></td>
                        <td><button class="up-btn"><a href="../php/update.php?id=<?php echo $row['Id']; ?>">Update</a></button></td>

                <?php

                        echo "</tr>";
                    }

                    echo "</tbody>";
                } else {
                    echo "There are no Students!";
                }
                ?>
            </table>
        </div>
    </div>
</body>

</html>